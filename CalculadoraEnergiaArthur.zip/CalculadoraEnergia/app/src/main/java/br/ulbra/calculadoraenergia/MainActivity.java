package br.ulbra.calculadoraenergia;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText editConsumo, editPotencia, editTempo;
    Button btnCalculo;
    TextView txtR1, txtR2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        editConsumo = findViewById(R.id.edtConsumo);
        editPotencia = findViewById(R.id.edtPotencia);
        editTempo = findViewById(R.id.edtTempo);
        btnCalculo = findViewById(R.id.btnCalcular);
        txtR1 = findViewById(R.id.txtCusto);
        txtR2 = findViewById(R.id.txtPreco);

        btnCalculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double valorA, valorB, valorC, result1, result2;
                try {
                    valorA = Double.parseDouble(editConsumo.getText().toString());
                    valorB = Double.parseDouble(editPotencia.getText().toString());
                    valorC = Double.parseDouble(editTempo.getText().toString());
                    // Cálculo do consumo//
                    result1 = (valorB * valorC) / 1000;
                    //custo//
                    result2 = result1 * valorC;
                    //resultado//
                    txtR1.setText("O custo de energia é " + result1 );
                    txtR2.setText("O preço é " + result2);
                } catch (NumberFormatException e) {
                    Toast.makeText(v.getContext(),
                            "Por favor, preencha ambos os campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}