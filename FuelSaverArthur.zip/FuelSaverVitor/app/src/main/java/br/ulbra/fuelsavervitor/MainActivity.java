package br.ulbra.fuelsavervitor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText editNome, editPlaca, editDistancia, editConsumo, editPreco;
    Button btnCalculo;
    TextView txtR1, txtR2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        editNome = findViewById(R.id.edtNome);
        editPlaca = findViewById(R.id.edtPlaca);
        editDistancia = findViewById(R.id.edtDistancia);
        editConsumo = findViewById(R.id.edtConsumo);
        editPreco = findViewById(R.id.edtPreco);
        btnCalculo = findViewById(R.id.btnCalcular);
        txtR1 = findViewById(R.id.txtResultado1);
        txtR2 = findViewById(R.id.txtResultado2);

        btnCalculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double valorA, valorB, valorC, result1, result2;
                try {
                    valorA = Double.parseDouble(editDistancia.getText().toString());
                    valorB = Double.parseDouble(editConsumo.getText().toString());
                    valorC = Double.parseDouble(editPreco.getText().toString());
                    //Cálculo do consumo de combustível//
                    result1 = valorA / valorB;
                    //Cálculo do preço da viagem//
                    result2 = result1 * valorC;
                    //Resultados//

                    txtR1.setText("O combustível necessário é " + result1 + " Litros");
                    txtR1.setText("O preço total da viagem é " + result2 + " Reais");
                } catch (NumberFormatException e) {
                    Toast.makeText(v.getContext(),
                            "Por favor, preencha ambos os campos corretamente", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
