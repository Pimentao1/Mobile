package br.ulbra.appcalculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView txtResultado;
    EditText val1, val2;
    Button btnSomar;
    Button btnMulti ;
    Button btnDiv;
    Button btnSub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        val1 = findViewById(R.id.edtVal1);
        val2 = findViewById(R.id.edtVal2);
        btnSomar = findViewById(R.id.btnSomar);
        txtResultado = findViewById(R.id.txtResultado);

        btnSomar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double v1, v2, result;
                try {
                    v1 = Double.parseDouble(val1.getText().toString());
                    v2 = Double.parseDouble(val2.getText().toString());
                    result = v1 + v2;
                    txtResultado.setText("Resultado: A soma é " + result);
                } catch (NumberFormatException e) {
                    // Trata o erro caso algum campo esteja vazio ou tenha um valor inválido
                    Toast.makeText(MainActivity.this, "Por favor, preencha ambos os campos com números válidos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    btnSub.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            double v1, v2, result;
            try {
                v1 = Double.parseDouble(val1.getText().toString());
                v2 = Double.parseDouble(val2.getText().toString());
                result = v1 - v2;
                txtResultado.setText("Resultado: A subtração é " + result);
            } catch (NumberFormatException e) {
                // Trata o erro caso algum campo esteja vazio ou tenha um valor inválido
                Toast.makeText(MainActivity.this, "Por favor, preencha ambos os campos com números válidos", Toast.LENGTH_SHORT).show();
            }
        }
    });
    btnMulti.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            double v1, v2, result;
            try {
                v1 = Double.parseDouble(val1.getText().toString());
                v2 = Double.parseDouble(val2.getText().toString());
                result = v1 * v2;
                txtResultado.setText("Resultado: A Multiplicação é " + result);
            } catch (NumberFormatException e) {
                // Trata o erro caso algum campo esteja vazio ou tenha um valor inválido
                Toast.makeText(MainActivity.this, "Por favor, preencha ambos os campos com números válidos", Toast.LENGTH_SHORT).show();
            }
        }
    });
    btnDiv.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            double v1, v2, result;
            try {
                v1 = Double.parseDouble(val1.getText().toString());
                v2 = Double.parseDouble(val2.getText().toString());
                result = v1 / v2;
                txtResultado.setText("Resultado: A soma é " + result);
            } catch (NumberFormatException e) {
                // Trata o erro caso algum campo esteja vazio ou tenha um valor inválido
                Toast.makeText(MainActivity.this, "Por favor, preencha ambos os campos com números válidos", Toast.LENGTH_SHORT).show();
            }
        }
    });
    }
}