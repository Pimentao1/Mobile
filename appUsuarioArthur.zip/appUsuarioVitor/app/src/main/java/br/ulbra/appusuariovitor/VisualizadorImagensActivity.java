package br.ulbra.appusuariovitor;


import android.os.Bundle;
import android.app.Activity;
import android.widget.*;
import android.view.*;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class VisualizadorImagensActivity extends AppCompatActivity {

    ImageView imgfoto;
    Button btfoto1, btfoto2;
    TextView txtinformacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_visualizador_imagen);
        imgfoto = (ImageView) findViewById(R.id.imgFoto);
        btfoto1 = (Button) findViewById(R.id.btFoto1);
        btfoto2 = (Button) findViewById(R.id.btFoto2);
        txtinformacao = (TextView) findViewById(R.id.txtInformacao);

        btfoto1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgfoto.setImageResource(R.drawable.yonechibi);
                txtinformacao.setText("Foto 1");
            }
        });

        btfoto2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgfoto.setImageResource(R.drawable.yasuochibi);
                txtinformacao.setText("Foto 2");
            }
        });
    }
}